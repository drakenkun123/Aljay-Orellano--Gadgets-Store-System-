﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GadgetStore_WindowsForm_
{
    class ConnectAPI
    {
        public static async Task DgvResultView(DataGridView dgv, string apiUrl)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string responseData = await response.Content.ReadAsStringAsync();

                    JObject jsonResponse = JObject.Parse(responseData);
                    JArray dataArray = jsonResponse["Result"] as JArray;

                    if (dataArray != null)
                    {
                        DataTable dataTable = JsonConvert.DeserializeObject<DataTable>(dataArray.ToString());

                        dgv.DataSource = dataTable;

                        // Correct timezone display for 'datetime' column
                        foreach (DataGridViewRow row in dgv.Rows)
                        {
                            if (row.Cells["datetime"].Value != null)
                            {
                                if (DateTime.TryParse(row.Cells["datetime"].Value.ToString(), out DateTime parsedDate))
                                {
                                    // Adjust if necessary (assumes UTC from backend)
                                    parsedDate = DateTime.SpecifyKind(parsedDate, DateTimeKind.Utc).ToLocalTime();

                                    // Display format: dd/MM/yyyy hh:mm tt
                                    row.Cells["datetime"].Value = parsedDate.ToString("dd/MM/yyyy hh:mm tt");
                                }
                            }
                        }

                        // Format headers
                        foreach (DataGridViewColumn column in dgv.Columns)
                        {
                            column.HeaderText = FormatHeaderText(column.HeaderText);
                        }

                        // Optionally, hide ID column
                        if (dgv.Columns.Contains("id"))
                        {
                            dgv.Columns["id"].Visible = false;
                        }

                        dgv.Refresh();
                    }
                    else
                    {
                        MessageBox.Show("Error parsing data");
                    }
                }
                else
                {
                    MessageBox.Show("Error fetching data");
                }
            }
        }


        // Helper to convert snake_case or camelCase to Proper Format
        private static string FormatHeaderText(string original)
        {
            // Replace underscores with spaces and capitalize each word
            return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(original.Replace("_", " "));
        }
    }
}
