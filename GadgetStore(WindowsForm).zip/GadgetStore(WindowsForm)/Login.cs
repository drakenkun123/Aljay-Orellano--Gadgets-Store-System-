﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GadgetStore_WindowsForm_
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            var client = new HttpClient();

            var credentials = new
            {
                username = tbxUsername.Text,
                password = tbxPassword.Text
            };

            var json = JsonConvert.SerializeObject(credentials);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                HttpResponseMessage response = await client.PostAsync("http://localhost:3000/auth/login", content);
                string result = await response.Content.ReadAsStringAsync();

                dynamic loginResult = JsonConvert.DeserializeObject(result);

                if (loginResult.loginStatus == true)
                {
                    Dashboard form = new Dashboard();
                    this.Hide();
                    form.Show();
                }
                else
                {
                    lblPasswordCheck.Show();
                    lblUsernameCheck.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to the server: " + ex.Message);
            }
        }

        private void tbxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            tbxPassword.PasswordChar = '*';
        }
    }
}
