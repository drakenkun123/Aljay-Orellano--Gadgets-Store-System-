﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GadgetStore_WindowsForm_
{
    public partial class Cashier : Form
    {

        private List<GadgetItem> gadgetItems = new List<GadgetItem>();
        private const string apiUrl = "http://localhost:3000/auth/gadgets"; // Adjust this API URL as needed
        public Cashier()
        {
            InitializeComponent();
        }

        private void Cashier_Load(object sender, EventArgs e)
        {
            InitializeDgvColumns();
            LoadGadgetItems();
            tbxCash.TextChanged += CashOrQuantityChanged;
            btnCheckout.Click += BtnCheckout_Click;
            btnCheckout.Enabled = false;

            dgvSelectedItems.CellContentClick += dgvSelectedItems_CellContentClick;
            tbxCash.KeyPress += tbxCash_KeyPress;
            tbxTotal.ReadOnly = true;
            tbxChange.ReadOnly = true;
        }
        private void InitializeDgvColumns()
        {
            dgvSelectedItems.Columns.Clear();
            dgvSelectedItems.Columns.Add("Name", "Name");
            dgvSelectedItems.Columns.Add("Price", "Price");
            dgvSelectedItems.Columns.Add("Quantity", "Quantity");
            dgvSelectedItems.Columns.Add("Total", "Total");

            DataGridViewButtonColumn deleteColumn = new DataGridViewButtonColumn
            {
                Name = "Delete",
                Text = "X",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Flat
            };
            dgvSelectedItems.Columns.Add(deleteColumn);

            dgvSelectedItems.Columns["Price"].DefaultCellStyle.Format = "N2";
            dgvSelectedItems.Columns["Total"].DefaultCellStyle.Format = "N2";
            dgvSelectedItems.Columns["Delete"].HeaderText = "";
            dgvSelectedItems.Columns["Delete"].SortMode = DataGridViewColumnSortMode.Automatic;
        }
        private void dgvSelectedItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == dgvSelectedItems.Columns["Delete"].Index && e.RowIndex >= 0)
                {
                    dgvSelectedItems.Rows.RemoveAt(e.RowIndex);
                    UpdateTotalAndChange();
                }
            }
            catch { }
        }
        private async void LoadGadgetItems()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string json = await client.GetStringAsync(apiUrl);
                    JObject result = JObject.Parse(json);
                    if (result["Status"]?.Value<bool>() == true)
                    {
                        JArray data = (JArray)result["Result"];
                        foreach (var item in data)
                        {
                            var partItem = new GadgetItem
                            {
                                Id = item.Value<int>("id"),
                                Name = item.Value<string>("name"),
                                Price = item.Value<decimal>("price"),
                                Image = item.Value<string>("image"),
                                Quantity = item.Value<int>("quantity")
                            };

                            gadgetItems.Add(partItem);
                            AddGadgetItemToPanel(partItem);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load part items: " + ex.Message);
            }
        }
        private void AddGadgetItemToPanel(GadgetItem item)
        {
            Panel itemPanel = new Panel
            {
                Width = 101,
                Height = 180,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White
            };

            Button btnImage = new Button
            {
                Width = 100,
                Height = 120,
                Text = "",
                TextAlign = ContentAlignment.MiddleCenter,
                FlatStyle = FlatStyle.Flat,
                Image = StretchImageToSize(LoadImageFromUrl($"http://localhost:3000/Images/{item.Image}"), 100, 120),
                ImageAlign = ContentAlignment.MiddleCenter,
                Tag = item
            };

            Label lblNamePrice = new Label
            {
                Width = 100,
                Height = 40,
                Text = $"{item.Name}\nPhp {item.Price:F2}",
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 120),
                Font = new Font("Arial", 10, FontStyle.Bold)
            };

            Button btnDelete = new Button
            {
                Text = "X",
                Width = 20,
                Height = 20,
                Location = new Point(85, 0),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.Red,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };

            btnDelete.Click += (s, e) => DeleteGadgetItem(itemPanel, item);
            itemPanel.Controls.Add(btnImage);
            itemPanel.Controls.Add(lblNamePrice);
            itemPanel.Controls.Add(btnDelete);

            panelGadget.Controls.Add(itemPanel);
            btnImage.Click += GadgetItem_Click;
        }
        private void DeleteGadgetItem(Panel itemPanel, GadgetItem item)
        {
            panelGadget.Controls.Remove(itemPanel);

            foreach (DataGridViewRow row in dgvSelectedItems.Rows)
            {
                if (row.Cells["Name"].Value?.ToString() == item.Name)
                {
                    dgvSelectedItems.Rows.Remove(row);
                    UpdateTotalAndChange();
                    break;
                }
            }
        }
        private Image StretchImageToSize(Image originalImage, int width, int height)
        {
            Bitmap stretchedImage = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(stretchedImage))
            {
                g.DrawImage(originalImage, 0, 0, width, height);
            }
            return stretchedImage;
        }
        private Image LoadImageFromUrl(string url)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var stream = client.GetStreamAsync(url).Result;
                    return Image.FromStream(stream);
                }
            }
            catch
            {
                return new Bitmap(100, 100);
            }
        }
        private void GadgetItem_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            var item = btn.Tag as GadgetItem;

            // Check if item is already out of stock
            if (item.Quantity <= 0)
            {
                MessageBox.Show("Part is not available.");
                return;
            }

            foreach (DataGridViewRow row in dgvSelectedItems.Rows)
            {
                if (row.Cells["Name"].Value?.ToString() == item.Name)
                {
                    int qty = int.Parse(row.Cells["Quantity"].Value.ToString()) + 1;

                    if (qty > item.Quantity)
                    {
                        MessageBox.Show("Out of stock.");
                        return;
                    }

                    row.Cells["Quantity"].Value = qty;
                    row.Cells["Total"].Value = (qty * item.Price).ToString("F2");
                    UpdateTotalAndChange();
                    return;
                }
            }

            dgvSelectedItems.Rows.Add(item.Name, item.Price.ToString("F2"), 1, item.Price.ToString("F2"));
            UpdateTotalAndChange();
        }

        private void CashOrQuantityChanged(object sender, EventArgs e)
        {
            UpdateTotalAndChange();
        }
        private void UpdateTotalAndChange()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in dgvSelectedItems.Rows)
            {
                if (decimal.TryParse(row.Cells["Total"].Value?.ToString(), out decimal rowTotal))
                {
                    total += rowTotal;
                }
            }

            tbxTotal.Text = total.ToString("F2");

            if (decimal.TryParse(tbxCash.Text, out decimal cash))
            {
                decimal change = cash - total;
                tbxChange.Text = (change >= 0 ? change : 0).ToString("F2");
                btnCheckout.Enabled = change >= 0;
            }
            else
            {
                tbxChange.Text = "0.00";
                btnCheckout.Enabled = false;
            }
        }
        private async void BtnCheckout_Click(object sender, EventArgs e)
        {
            var customerName = tbxCustomerName.Text;
            var cash = decimal.Parse(tbxCash.Text);
            var total = decimal.Parse(tbxTotal.Text);
            var change = decimal.Parse(tbxChange.Text);

            var paymentData = new
            {
                customer_name = customerName,
                cash,
                change,
                total
            };

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var content = new StringContent(
                        Newtonsoft.Json.JsonConvert.SerializeObject(paymentData),
                        Encoding.UTF8,
                        "application/json");

                    var response = await client.PostAsync("http://localhost:3000/auth/sale", content);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Checkout successful!");
                        foreach (DataGridViewRow row in dgvSelectedItems.Rows)
                        {
                            string name = row.Cells["Name"].Value.ToString();
                            int qtyBought = int.Parse(row.Cells["Quantity"].Value.ToString());

                            var item = gadgetItems.FirstOrDefault(i => i.Name == name);
                            if (item != null)
                            {
                                int updatedQty = item.Quantity - qtyBought;
                                if (updatedQty < 0) updatedQty = 0;

                                var updateData = new
                                {
                                    quantity = updatedQty
                                };

                                var updateContent = new StringContent(
                                    Newtonsoft.Json.JsonConvert.SerializeObject(updateData),
                                    Encoding.UTF8,
                                    "application/json");

                                await client.PutAsync($"http://localhost:3000/auth/update_quantity/{item.Id}", updateContent);

                                // Optional: update local quantity in memory
                                item.Quantity = updatedQty;
                            }
                        }

                        ResetForm();

                    }
                    else
                    {
                        MessageBox.Show("Checkout failed.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during checkout: " + ex.Message);
            }
        }
        private void ResetForm()
        {
            dgvSelectedItems.Rows.Clear();
            tbxCustomerName.Text = "";
            tbxCash.Text = "";
            tbxTotal.Text = "0.00";
            tbxChange.Text = "0.00";
            btnCheckout.Enabled = false;
        }
        private void tbxCash_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.' || tbxCash.Text.Contains("."));
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Dashboard f = new Dashboard();
            this.Hide();
            f.Show();
        }
    }
}
