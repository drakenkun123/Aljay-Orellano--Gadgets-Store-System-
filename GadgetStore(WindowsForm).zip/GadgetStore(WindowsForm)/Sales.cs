﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GadgetStore_WindowsForm_
{
    public partial class Sales : Form
    {
        public Sales()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Dashboard f = new Dashboard();
            this.Hide();
            f.Show();
        }

        private async void Sales_Load(object sender, EventArgs e)
        {
            try
            {
                string url = "http://localhost:3000/auth/payment_history";
                await ConnectAPI.DgvResultView(dgvSales, url);

                // Compute total sales and number of sales from dgvHistory
                int numberOfSales = dgvSales.Rows.Count;
                decimal totalSales = 0;

                foreach (DataGridViewRow row in dgvSales.Rows)
                {
                    if (row.Cells["total"].Value != null)
                    {
                        totalSales += Convert.ToDecimal(row.Cells["total"].Value);
                    }
                }

                lblNumberOfSales.Text = numberOfSales.ToString();
                lblTotalSale.Text = totalSales.ToString("N2"); // Format as currency-style number
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}
