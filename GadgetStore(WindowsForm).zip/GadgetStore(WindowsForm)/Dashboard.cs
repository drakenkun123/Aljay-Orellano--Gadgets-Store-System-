﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GadgetStore_WindowsForm_
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Dashboard form = new Dashboard();
            this.Hide();
            form.Show();
        }

        private void btnCashier_Click(object sender, EventArgs e)
        {
            Cashier form = new Cashier();
            this.Hide();
            form.Show();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            Sales form = new Sales();
            this.Hide();
            form.Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login form = new Login();
            this.Hide();
            form.Show();
        }
    }
}
